package Modelo;

public enum TipoUsuario {
    Cliente,
    Admin
}
