package Visão;

public interface Atualizavel {
    void atualizarInterface();
}
