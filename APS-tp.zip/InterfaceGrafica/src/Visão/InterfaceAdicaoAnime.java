package Visão;

import javax.swing.*;

public class InterfaceAdicaoAnime extends JPanel {
    public InterfaceAdicaoAnime(GerenciadorInterfaces gerenciador) {

    }
}
