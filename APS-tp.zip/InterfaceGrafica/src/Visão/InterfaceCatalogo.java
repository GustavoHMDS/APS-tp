package Visão;

import javax.swing.*;

public class InterfaceCatalogo extends JPanel {
    public InterfaceCatalogo(GerenciadorInterfaces gerenciador) {

    }
}
